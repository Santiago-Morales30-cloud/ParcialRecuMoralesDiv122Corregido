package parcialrecumoralesdiv122;


public class Charla extends Actividad implements PresentacionPublica, ReservarLugares {
    
    private final int minutosDesPreguntas;
    private int cuposDisponibles;


    public Charla(String codigo, String titulo, FranjaHoraria franjaHoraria , int duracionBase, int minutosDesPreguntas,  int cuposDisponibles) {
        super(codigo, titulo, duracionBase, franjaHoraria);
        validarNumerosNegativos(minutosDesPreguntas, "Los minutos de preguntas ");
        validarNumerosNegativos(cuposDisponibles, "Los cupos disponibles ");
        this.minutosDesPreguntas = minutosDesPreguntas;
        this.cuposDisponibles = cuposDisponibles;
    }

    @Override
    public int duracionTotal() {
        return getDuracionBase() + minutosDesPreguntas;
    }

    @Override
    public String realizarPresentacionPublica() {
        return "La charla" + getTitulo() + "puede realizar presentaciones publicas";
    }

    @Override
    public String reservarLugares() {
        if (cuposDisponibles <= 0){
            throw new IllegalStateException("No quedan lugares para reservar.");
        }
        cuposDisponibles -= 1;
        return "Se gasto un cupo disponible de " + getTitulo() + ", en total quedan" + cuposDisponibles;
    }    

    @Override
    public String toString() {
        return "Charla{" + descripcionGeneral() + "minutosDesPreguntas=" + minutosDesPreguntas + ", cuposDisponibles=" + cuposDisponibles + '}';
    }
    
    
    
    
}
