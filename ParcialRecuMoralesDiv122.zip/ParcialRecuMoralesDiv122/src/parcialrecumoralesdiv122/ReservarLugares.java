package parcialrecumoralesdiv122;


public interface ReservarLugares {
    
    String reservarLugares();
    
    
}


