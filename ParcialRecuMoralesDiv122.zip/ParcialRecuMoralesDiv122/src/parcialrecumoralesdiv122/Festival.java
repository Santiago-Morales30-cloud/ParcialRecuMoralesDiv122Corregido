
package parcialrecumoralesdiv122;

import java.util.ArrayList;
import java.util.List;

public class Festival {
   
    private final String nombre;
    private List<Actividad> actividades;

    public Festival(String nombre) {
        this.nombre = nombre;
        actividades = new ArrayList<>();
    }

    public String getNombre() {
        return nombre;
    }
    
    private static void validarActividad(Actividad nuevaActividad){
        if (nuevaActividad == null){
            throw new IllegalArgumentException("La actividad no puede ser null.");
        }
    
    }
    
    
    public void agregarActividad(Actividad nuevaActividad) throws ActividadDuplicadaException, IllegalAccessException{
        validarActividad(nuevaActividad);
        if (actividades.contains(nuevaActividad)){
            throw new ActividadDuplicadaException();
        }
        actividades.add(nuevaActividad);
    }
    
    
    
    public ArrayList<Actividad> obtenerActividades(){
        return new ArrayList<>(actividades);
    }
    
    
    
    private static void validarFranja(FranjaHoraria franja){
        if (franja == null){
            throw new IllegalArgumentException("La franja no puede ser null.");
        }
    }
    
    
    
    public List<Actividad> filtrarPorFranja(FranjaHoraria franja){
        validarFranja(franja);
        List<Actividad> resultado = new ArrayList<>();
        for (Actividad actividad : actividades){
            if(actividad.getFranjaHoraria() == franja){
                resultado.add(actividad);
            }
        }
        return resultado;
    }
    
    
    private static void validarMinimo(int minimo){
        if (minimo < 0){
            throw new IllegalArgumentException("El minimo tiene que ser positivo.");
        }
    }
    
    
    public List<Actividad> obtenerActividadesDeDuracionMaxima(int minimo){
        validarMinimo(minimo);
        List<Actividad> resultado = new ArrayList<>();
        for (Actividad actividad : actividades){
            if(actividad.duracionTotal() >= minimo){
                resultado.add(actividad);
            }
        }
        return resultado;
    }

    @Override
    public String toString() {
        return "Festival{" + "nombre=" + nombre + '}';
    }
    
    
}
