
package parcialrecumoralesdiv122;

import java.util.Objects;


public abstract class Actividad {
    
    private final String codigo;
    private final String titulo;
    private final FranjaHoraria franjaHoraria;
    private final int duracionBase;

    public Actividad(String codigo, String titulo, int duracionBase, FranjaHoraria franjaHoraria) {
        validarTexto(codigo, "El codigo");
        validarTexto(titulo, "El titulo");
        validarFranjaHoraria(franjaHoraria);
        validarNumeros(duracionBase, "La duracion base");
        this.codigo = codigo;
        this.titulo = titulo;
        this.duracionBase = duracionBase;
        this.franjaHoraria = franjaHoraria;
    }

    protected void validarTexto(String valor, String mensaje){
        if (valor == null || valor.isBlank()){
            throw new IllegalArgumentException(mensaje + " no puede ser null ni blanco.");
        }
    }
    
    private static void validarFranjaHoraria(FranjaHoraria franjaHoraria){
        if (franjaHoraria == null){
            throw new IllegalArgumentException("La franja es obligatoria.");
        }
    }
    
    protected void validarNumerosNegativos(int valor, String mensaje){
        if (valor < 0){
            throw new IllegalArgumentException(mensaje + " no tiene que ser negativo.");
        }
    }
    
    protected void validarNumeros(int valor, String mensaje){
        if (valor <= 0){
            throw new IllegalArgumentException(mensaje + " tiene que ser mayor a 0.");
        }
    }
    
    
    public String getCodigo() {
        return codigo;
    }

    public String getTitulo() {
        return titulo;
    }

    public int getDuracionBase() {
        return duracionBase;
    }

    public FranjaHoraria getFranjaHoraria() {
        return franjaHoraria;
    }
    
    
    public abstract int duracionTotal();

    @Override
    public int hashCode() {
        return Objects.hash(codigo, titulo);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Actividad otro)){
            return false;
        }
        return codigo.equals(otro.codigo) && titulo.equals(otro.titulo);
    }

    
    protected String descripcionGeneral(){
        return ("codigo=" + codigo + ", titulo=" + titulo + ", franjaHoraria=" + franjaHoraria + ", duracionBase=" + duracionBase);
    }
    
    @Override
    public String toString() {
        return "Actividad{" + "codigo=" + codigo + ", titulo=" + titulo + ", franjaHoraria=" + franjaHoraria + ", duracionBase=" + duracionBase + '}';
    }
    
    
    
}
