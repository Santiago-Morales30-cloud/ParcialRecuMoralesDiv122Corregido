package parcialrecumoralesdiv122;

public class Taller extends Actividad implements ReservarLugares {
    
    private final int minutosAdiPractica;
    private int cuposDisponibles;


    public Taller(String codigo, String titulo,FranjaHoraria franjaHoraria, int duracionBase, int minutosAdiPractica, int cuposDisponibles) {
        super(codigo, titulo, duracionBase, franjaHoraria);
        validarNumerosNegativos(minutosAdiPractica, "Los minutos de practica ");
        validarNumeros(cuposDisponibles, "Los cupos disponibles ");
        this.minutosAdiPractica = minutosAdiPractica;
        this.cuposDisponibles = cuposDisponibles;
    }
    
    
    @Override
    public int duracionTotal() {
        return getDuracionBase() + minutosAdiPractica;
    }

    
    @Override
    public String reservarLugares() {
        if (cuposDisponibles <= 0){
            throw new IllegalStateException("No quedan lugares para reservar.");
        }
        cuposDisponibles -= 1;
        return "Se gasto un cupo disponible de " + getTitulo() + ", en total quedan" + cuposDisponibles;
    }

    @Override
    public String toString() {
        return "Taller{" + descripcionGeneral() + "minutosAdiPractica=" + minutosAdiPractica + ", cuposDisponibles=" + cuposDisponibles + '}';
    }


    
    
}
