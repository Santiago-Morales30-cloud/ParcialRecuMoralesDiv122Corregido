
package parcialrecumoralesdiv122;


public enum FranjaHoraria {
    
    MATUTINA,
    VESPERTINA,
    NOCTURNA;
    
    
}
