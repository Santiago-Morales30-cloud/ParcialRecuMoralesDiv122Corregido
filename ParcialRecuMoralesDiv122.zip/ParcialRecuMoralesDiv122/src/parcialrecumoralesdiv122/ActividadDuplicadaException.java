
package parcialrecumoralesdiv122;


public class ActividadDuplicadaException extends Exception {

    public static final String DEFAULT_MESSAGE = "La actividad esta duplicada, tiene el mismo codigo y titulo";
    
    public ActividadDuplicadaException() throws IllegalAccessException {
        this(DEFAULT_MESSAGE);
    }

    public ActividadDuplicadaException(String mensaje) throws IllegalAccessException {
        if (mensaje == null){
            throw new IllegalAccessException("El mensaje no puede ser null.");
        }
        super(mensaje);
    }
}
