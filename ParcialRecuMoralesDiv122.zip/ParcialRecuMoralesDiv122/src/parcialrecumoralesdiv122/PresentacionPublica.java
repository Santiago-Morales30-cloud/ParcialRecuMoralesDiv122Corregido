package parcialrecumoralesdiv122;


public interface PresentacionPublica {
    
    String realizarPresentacionPublica();
    
    
}
