package parcialrecumoralesdiv122;


public class MuestraInteractiva extends Actividad implements PresentacionPublica {
    
    private final int cantidadEstaciones;

    public MuestraInteractiva(String codigo, String titulo,FranjaHoraria franjaHoraria, int duracionBase, int cantidadEstaciones ) {
        super(codigo, titulo, duracionBase, franjaHoraria);
        validarNumeros(cantidadEstaciones, "La cantidad de estaciones ");
        this.cantidadEstaciones = cantidadEstaciones;
    }

    public int getCantidadEstaciones() {
        return cantidadEstaciones;
    }

    @Override
    public int duracionTotal() {
        return getDuracionBase() + (5 * cantidadEstaciones);
    }

    @Override
    public String realizarPresentacionPublica() {
        return "El taller" + getTitulo() + "puede realizar presentaciones publicas";
    }

    @Override
    public String toString() {
        return "MuestraInteractiva{" + descripcionGeneral() + "cantidadEstaciones=" + cantidadEstaciones + '}';
    }

    
    
    
    
    
}
